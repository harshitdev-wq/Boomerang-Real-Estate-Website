# Boomerang Real Estate

A modern real-estate web experience built with React, TypeScript, Vite, and Tailwind CSS.

## Live Demo

https://boomerangrealestate.netlify.app/

## Development

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
```
